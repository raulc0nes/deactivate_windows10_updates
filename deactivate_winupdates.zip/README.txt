### por si algune quiere desactivar las actualizaciones automáticas de su windows 10 por algo ###
1.- doble clic en 'start.cmd'
2.- seguir instrucciones

## se usan varias técnicas para evitar la persistencia de los instaladores de actualización en el sistema
## se crean reglas en el firewall para bloquear conexiones a ips de servidores de actualizaciones conocidos
## se crean tareas programadas para que se ejecuten bucles en cada inicio de sistema registrando y alertando sobre cambios y conexiones de manera visual sin instalar aplicaciones externas (o de terceros)
# con la colaboración de OpenAI
@raulc0nes


  adding: deactivate.bat (deflated 75%)
  adding: deactivate-takeown.bat (deflated 75%)
  adding: monitor.bat (deflated 69%)
  adding: README.txt (deflated 43%)
  adding: start.bat (deflated 84%)

357226c8e3a4912864160d8f2b55e70707d00e2c7eb33c1ef6b19ee1aaadf4df  deactivate_winupdates.zip
